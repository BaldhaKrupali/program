package Day11_CovariantType;

public class MainCovariant {
	public static void main(String[] args){
		Parent p = new Parent();
		Child c = new Child();
		p.show();
		c.show();
	}
}

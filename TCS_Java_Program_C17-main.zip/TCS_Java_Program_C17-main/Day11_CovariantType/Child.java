package Day11_CovariantType;

public class Child {
	public Object show(){
		Object ob = null;
		System.out.println("Child Class");
		return ob;
	}
}

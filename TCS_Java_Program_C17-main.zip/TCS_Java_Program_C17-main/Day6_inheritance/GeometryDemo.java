package Day6_inheritance;

public class GeometryDemo{
	public static void main(String[] args){
		
		City ci = new City();
		
		ci.setCname("India");
		ci.setSname("Gujarat");
		ci.setCn("Veraval");
		
		System.out.println(ci);
		
	}
}

package Day2;

public class AreaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area ob = new Area();
		ob.SetDimention(12.4f,17.12f);
		System.out.println("Area : "+ob.getArea());
	}

}

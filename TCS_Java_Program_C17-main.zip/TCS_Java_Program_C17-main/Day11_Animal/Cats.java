package Day11_Animal;

public class Cats extends Animal {
	@Override
	void cat(){
		System.out.println("Cat Meow");
	}
	
	@Override
	void dog(){
		
	}
}

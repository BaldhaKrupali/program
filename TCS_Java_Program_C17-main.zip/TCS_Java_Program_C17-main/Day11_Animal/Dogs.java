package Day11_Animal;

public class Dogs extends Animal{
	@Override
	void cat(){
		
	}
	
	@Override()
	void dog(){
		System.out.println("Dog bark");
	}
	
}

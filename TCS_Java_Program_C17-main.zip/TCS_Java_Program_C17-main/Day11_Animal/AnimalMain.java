package Day11_Animal;

public class AnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cats c = new Cats();
		Dogs d = new Dogs();
		
		c.cat();
		d.dog();
	}

}

package Day11_FunctionInterface;

@FunctionalInterface
public interface Gretting {
	public void fun();
}
